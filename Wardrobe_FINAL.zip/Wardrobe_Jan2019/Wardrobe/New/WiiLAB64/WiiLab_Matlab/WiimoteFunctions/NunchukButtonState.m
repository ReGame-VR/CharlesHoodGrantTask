% NunchuckButtons is the class that creates the data structure for storing the
% Button values from the Nunchuk

classdef NunchukButtonState
    
    properties 
        
        C = false;
        Z = false;
       
    end % properties
    
end
    