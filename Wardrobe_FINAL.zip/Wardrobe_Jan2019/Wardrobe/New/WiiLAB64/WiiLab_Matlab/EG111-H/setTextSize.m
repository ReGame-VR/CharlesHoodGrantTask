function setTextSize(tx, sz)
% setTextSize(tx, sz)
% sets tx's size to sz

set(tx, 'FontSize', sz)

