function setTitle(ttl)
%	usage:      setTitle (t)
%	purpose:	sets the window�s title to be the contents of the character
%	string named t
set(gcf, 'Name', ttl);